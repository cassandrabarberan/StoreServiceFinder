<style type="text/css">
  /* CSS to style Treeview menu  */
ol.tree {
  padding: 0 0 0 30px;
  width: 300px;
}
li { 
  position: relative; 
  margin-left: -15px;
  list-style: none;
}      
li input {
  position: absolute;
  left: 0;
  margin-left: 0;
  opacity: 0;
  z-index: 2;
  cursor: pointer;
  height: 1em;
  width: 1em;
  top: 0;
}
li input + ol {
  background: url(toggle-small-expand.png) 40px 0 no-repeat;
  margin: -1.600em 0px 8px -44px; 
  height: 1em;
}
li input + ol > li { 
  display: none; 
  margin-left: -14px !important; 
  padding-left: 1px; 
}
li label {
  background: url(folder.png) 15px 1px no-repeat;
  cursor: pointer;
  display: block;
  padding-left: 37px;
}
li input:checked + ol {
  background: url(toggle-small.png) 40px 5px no-repeat;
  margin: -1.96em 0 0 -44px; 
  padding: 1.563em 0 0 80px;
  height: auto;
}
li input:checked + ol > li { 
  display: block; 
  margin: 8px 0px 0px 0.125em;
}
li input:checked + ol > li:last-child { 
  margin: 8px 0 0.063em;
}
</style>