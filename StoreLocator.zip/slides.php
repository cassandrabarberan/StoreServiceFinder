 <div id="main-slider" class="flexslider">
            <ul class="slides">
      <!--         <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/Small-Rime.jpg" alt="" />
                <div class="flex-caption">
                    <h3>innovation</h3> 
          <p>We create the opportunities</p> 
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/maxresdefault.jpg" alt="" />
                <div class="flex-caption">
                    <h3>Pharmacy Finder</h3> 
          <p>Success depends on work</p> 
           
                </div>
              </li> -->
                  <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/banner.png" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
                  <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/banner.png" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/banner.png" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/banner.png" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>

              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/img5.jpg" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/img6.jpg" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/img7.jpg" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
              <li>
                <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/img8.jpg" alt="" />
                <div class="flex-caption">
                 <!--    <h3>The Generics Pharmacy</h3> 
                       <p>TG Pagpagaling nang sakit</p>  -->
           
                </div>
              </li>
            </ul>
        </div>