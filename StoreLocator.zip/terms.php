<section id="content">
    <div class="container content">  
		<h3>Terms and Conditions</h3>
		<p>  
		     Please read these terms and conditions of use carefully before using, accessing or obtaining any information, products or services of any materials found in this website. By using “Med-I-Seen” website, you agree to be bound by these terms and conditions. If you do not accept all of these Terms, then you may not use our website. In these Terms, “we”, “us”, or “our” refers to Med-I-Seen website, and “you” or “your” refers to you as the user of our Website. <br/> <br/> <br/>
		     
		     We may modify these Terms, for any reason at any time, by posting a new version on our Website. These changes do not affect rights and obligations that arise prior to such changes. Please review these Terms periodically for changes. If you object to any provision of these Terms or any subsequent modifications to these Terms or become dissatisfied with our Website in any way, your only recourse is to immediately terminate the use of our website.
		</p>
	</div>
</section>